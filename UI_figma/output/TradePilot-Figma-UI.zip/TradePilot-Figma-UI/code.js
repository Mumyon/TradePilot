const DESIGN={
  "colors": {
    "bg": "#0A0A0B",
    "panel": "#151516",
    "fg": "#F5F5F2",
    "muted": "#A1A1A6",
    "line": "#303034",
    "quiet": "#797980"
  },
  "screens": [
    {
      "name": "01 · 관심종목",
      "w": 390,
      "h": 844,
      "children": [
        {
          "type": "text",
          "value": "9:41",
          "x": 24,
          "y": 14,
          "w": 342,
          "h": 20,
          "size": 13,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "svg",
          "x": 304,
          "y": 18,
          "w": 62,
          "h": 12,
          "body": "<path d=\"M1 10V7H4V10ZM7 10V5H10V10ZM13 10V2H16V10Z\" fill=\"#F5F5F2\"/><path d=\"M22 3Q29 -2 36 3M25 6Q29 3 33 6\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\"/><rect x=\"43\" y=\"1\" width=\"17\" height=\"9\" fill=\"none\" stroke=\"#F5F5F2\"/><rect x=\"45\" y=\"3\" width=\"12\" height=\"5\" fill=\"#F5F5F2\"/>"
        },
        {
          "type": "text",
          "value": "MARKET / 시장을 읽다",
          "x": 24,
          "y": 55,
          "w": 342,
          "h": 15,
          "size": 10,
          "color": "muted",
          "weight": 600
        },
        {
          "type": "text",
          "value": "TradePilot",
          "x": 24,
          "y": 76,
          "w": 342,
          "h": 41,
          "size": 27,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "text",
          "value": "모의",
          "x": 326,
          "y": 85,
          "w": 40,
          "h": 17,
          "size": 11,
          "color": "muted",
          "weight": 600
        },
        {
          "type": "group",
          "name": "Bottom navigation",
          "x": 0,
          "y": 751,
          "w": 390,
          "h": 93,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 390,
              "h": 1,
              "color": "line"
            },
            {
              "type": "group",
              "name": "Tab / 관심종목",
              "x": 0,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M4 5H20M4 12H20M4 19H14\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "관심종목",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "fg",
                  "weight": 600
                }
              ],
              "target": 0,
              "centerText": true,
              "component": "Tab/0"
            },
            {
              "type": "group",
              "name": "Tab / 차트",
              "x": 97.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 4V20M3 9H7M3 15H7M12 2V17M10 5H14M10 11H14M19 8V22M17 12H21M17 18H21\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "차트",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 1,
              "centerText": true,
              "component": "Tab/1"
            },
            {
              "type": "group",
              "name": "Tab / 자동매매",
              "x": 195,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M13 2L5 13H11L10 22L20 9H13Z\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "자동매매",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 3,
              "centerText": true,
              "component": "Tab/2"
            },
            {
              "type": "group",
              "name": "Tab / 매매일지",
              "x": 292.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 3H19V21H5ZM9 7H15M9 11H15M9 15H13\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "매매일지",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 4,
              "centerText": true,
              "component": "Tab/3"
            },
            {
              "type": "rect",
              "x": 132,
              "y": 80,
              "w": 126,
              "h": 4,
              "color": "fg"
            }
          ]
        },
        {
          "type": "group",
          "name": "Market indices",
          "x": 24,
          "y": 130,
          "w": 342,
          "h": 66,
          "children": [
            {
              "type": "text",
              "value": "KOSPI",
              "x": 0,
              "y": 0,
              "w": 160,
              "h": 15,
              "size": 10,
              "color": "muted",
              "weight": 500
            },
            {
              "type": "text",
              "value": "2,684.72",
              "x": 0,
              "y": 19,
              "w": 160,
              "h": 30,
              "size": 20,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "▲ 0.84%",
              "x": 0,
              "y": 45,
              "w": 160,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "rect",
              "x": 171,
              "y": 0,
              "w": 1,
              "h": 61,
              "color": "line"
            },
            {
              "type": "text",
              "value": "NASDAQ",
              "x": 191,
              "y": 0,
              "w": 150,
              "h": 15,
              "size": 10,
              "color": "muted",
              "weight": 500
            },
            {
              "type": "text",
              "value": "17,918.99",
              "x": 191,
              "y": 19,
              "w": 150,
              "h": 30,
              "size": 20,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "▼ 0.21%",
              "x": 191,
              "y": 45,
              "w": 150,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "Segment navigation",
          "x": 24,
          "y": 217,
          "w": 342,
          "h": 42,
          "children": [
            {
              "type": "text",
              "value": "내 관심종목",
              "x": 0,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "rect",
              "x": 0,
              "y": 40,
              "w": 98,
              "h": 2,
              "color": "fg"
            },
            {
              "type": "text",
              "value": "국내",
              "x": 114,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "해외",
              "x": 228,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "Watchlist tools",
          "x": 24,
          "y": 276,
          "w": 342,
          "h": 38,
          "children": [
            {
              "type": "text",
              "value": "종목 / 거래소",
              "x": 0,
              "y": 9,
              "w": 342,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "svg",
              "x": 274,
              "y": 6,
              "w": 20,
              "h": 20,
              "body": "<path d=\"M16 16L22 22M18 10A8 8 0 1 0 2 10A8 8 0 1 0 18 10\" fill=\"none\" stroke=\"#A1A1A6\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
            },
            {
              "type": "svg",
              "x": 319,
              "y": 6,
              "w": 20,
              "h": 20,
              "body": "<path d=\"M12 3V21M3 12H21\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
            }
          ]
        },
        {
          "type": "group",
          "name": "Stock / 삼성전자",
          "x": 24,
          "y": 314,
          "w": 342,
          "h": 70,
          "children": [
            {
              "type": "text",
              "value": "삼성전자",
              "x": 0,
              "y": 12,
              "w": 140,
              "h": 23,
              "size": 15,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "005930 · KRX",
              "x": 0,
              "y": 36,
              "w": 140,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "svg",
              "x": 153,
              "y": 14,
              "w": 64,
              "h": 32,
              "body": "<polyline points=\"0.0,28.7 2.8,21.6 5.6,14.2 8.3,12.6 11.1,15.3 13.9,15.4 16.7,10.2 19.5,4.8 22.3,6.1 25.0,13.7 27.8,20.2 30.6,20.3 33.4,16.7 36.2,16.2 39.0,20.7 41.7,24.3 44.5,20.8 47.3,12.0 50.1,5.7 52.9,6.3 55.7,9.9 58.4,9.7 61.2,5.0 64.0,2.3\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.4\"/>"
            },
            {
              "type": "text",
              "value": "72,800",
              "x": 232,
              "y": 10,
              "w": 110,
              "h": 24,
              "size": 16,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "▲ 1,200  (1.68%)",
              "x": 232,
              "y": 35,
              "w": 110,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "rect",
              "x": 0,
              "y": 69,
              "w": 342,
              "h": 1,
              "color": "line"
            }
          ],
          "target": 1
        },
        {
          "type": "group",
          "name": "Stock / SK하이닉스",
          "x": 24,
          "y": 384,
          "w": 342,
          "h": 70,
          "children": [
            {
              "type": "text",
              "value": "SK하이닉스",
              "x": 0,
              "y": 12,
              "w": 140,
              "h": 23,
              "size": 15,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "000660 · KRX",
              "x": 0,
              "y": 36,
              "w": 140,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "svg",
              "x": 153,
              "y": 14,
              "w": 64,
              "h": 32,
              "body": "<polyline points=\"0.0,19.3 2.8,10.9 5.6,8.5 8.3,12.0 11.1,14.6 13.9,12.1 16.7,7.9 19.5,9.2 22.3,16.8 25.0,24.0 27.8,24.4 30.6,19.4 33.4,16.2 36.2,18.2 39.0,21.0 41.7,17.9 44.5,9.3 47.3,2.7 50.1,3.6 52.9,9.0 55.7,11.6 58.4,9.0 61.2,6.6 64.0,10.2\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.4\"/>"
            },
            {
              "type": "text",
              "value": "173,500",
              "x": 232,
              "y": 10,
              "w": 110,
              "h": 24,
              "size": 16,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "▲ 2,500  (1.46%)",
              "x": 232,
              "y": 35,
              "w": 110,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "rect",
              "x": 0,
              "y": 69,
              "w": 342,
              "h": 1,
              "color": "line"
            }
          ],
          "target": 1
        },
        {
          "type": "group",
          "name": "Stock / NAVER",
          "x": 24,
          "y": 454,
          "w": 342,
          "h": 70,
          "children": [
            {
              "type": "text",
              "value": "NAVER",
              "x": 0,
              "y": 12,
              "w": 140,
              "h": 23,
              "size": 15,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "035420 · KRX",
              "x": 0,
              "y": 36,
              "w": 140,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "svg",
              "x": 153,
              "y": 14,
              "w": 64,
              "h": 32,
              "body": "<polyline points=\"0.0,5.9 2.8,11.6 5.6,18.8 8.3,20.6 11.1,17.7 13.9,16.6 16.7,21.0 19.5,26.6 22.3,26.0 25.0,18.5 27.8,11.0 30.6,9.6 33.4,12.5 36.2,12.8 39.0,8.0 41.7,3.1 44.5,4.9 47.3,12.8 50.1,19.3 52.9,19.1 55.7,15.1 58.4,14.4 61.2,18.6 64.0,21.6\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.4\"/>"
            },
            {
              "type": "text",
              "value": "168,200",
              "x": 232,
              "y": 10,
              "w": 110,
              "h": 24,
              "size": 16,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "▼ 1,800  (1.06%)",
              "x": 232,
              "y": 35,
              "w": 110,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "rect",
              "x": 0,
              "y": 69,
              "w": 342,
              "h": 1,
              "color": "line"
            }
          ],
          "target": 1
        },
        {
          "type": "group",
          "name": "Stock / Apple",
          "x": 24,
          "y": 524,
          "w": 342,
          "h": 70,
          "children": [
            {
              "type": "text",
              "value": "Apple",
              "x": 0,
              "y": 12,
              "w": 140,
              "h": 23,
              "size": 15,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "AAPL · NASDAQ",
              "x": 0,
              "y": 36,
              "w": 140,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "svg",
              "x": 153,
              "y": 14,
              "w": 64,
              "h": 32,
              "body": "<polyline points=\"0.0,25.6 2.8,28.6 5.6,24.3 8.3,18.5 11.1,17.6 13.9,20.4 16.7,20.1 19.5,13.5 22.3,5.6 25.0,3.9 27.8,9.1 30.6,14.6 33.4,14.6 36.2,11.5 39.0,12.1 41.7,18.5 44.5,24.8 47.3,24.1 50.1,17.2 52.9,11.2 55.7,11.2 58.4,13.6 61.2,11.8 64.0,5.0\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.4\"/>"
            },
            {
              "type": "text",
              "value": "213.07",
              "x": 232,
              "y": 10,
              "w": 110,
              "h": 24,
              "size": 16,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "▲ 1.18  (0.56%)",
              "x": 232,
              "y": 35,
              "w": 110,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "rect",
              "x": 0,
              "y": 69,
              "w": 342,
              "h": 1,
              "color": "line"
            }
          ],
          "target": 1
        },
        {
          "type": "group",
          "name": "Pilot insight",
          "x": 24,
          "y": 619,
          "w": 342,
          "h": 91,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 91,
              "color": "panel"
            },
            {
              "type": "svg",
              "x": 14,
              "y": 15,
              "w": 20,
              "h": 20,
              "body": "<path d=\"M12 2L21 6V13L17 19L12 22L7 19L3 13V6ZM8 12L11 15L16 9\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
            },
            {
              "type": "text",
              "value": "오늘도, 계획대로.",
              "x": 46,
              "y": 12,
              "w": 270,
              "h": 21,
              "size": 14,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "관심종목의 AI 근거를 확인하고 거래하세요.",
              "x": 16,
              "y": 43,
              "w": 310,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "샘플 시세 · 실시간 데이터 아님",
              "x": 16,
              "y": 65,
              "w": 310,
              "h": 15,
              "size": 10,
              "color": "quiet",
              "weight": 400
            }
          ]
        }
      ]
    },
    {
      "name": "02 · 차트와 AI 분석",
      "w": 390,
      "h": 844,
      "children": [
        {
          "type": "text",
          "value": "9:41",
          "x": 24,
          "y": 14,
          "w": 342,
          "h": 20,
          "size": 13,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "svg",
          "x": 304,
          "y": 18,
          "w": 62,
          "h": 12,
          "body": "<path d=\"M1 10V7H4V10ZM7 10V5H10V10ZM13 10V2H16V10Z\" fill=\"#F5F5F2\"/><path d=\"M22 3Q29 -2 36 3M25 6Q29 3 33 6\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\"/><rect x=\"43\" y=\"1\" width=\"17\" height=\"9\" fill=\"none\" stroke=\"#F5F5F2\"/><rect x=\"45\" y=\"3\" width=\"12\" height=\"5\" fill=\"#F5F5F2\"/>"
        },
        {
          "type": "text",
          "value": "005930 / KRX",
          "x": 24,
          "y": 55,
          "w": 342,
          "h": 15,
          "size": 10,
          "color": "muted",
          "weight": 600
        },
        {
          "type": "text",
          "value": "삼성전자",
          "x": 24,
          "y": 76,
          "w": 342,
          "h": 41,
          "size": 27,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "text",
          "value": "모의",
          "x": 326,
          "y": 85,
          "w": 40,
          "h": 17,
          "size": 11,
          "color": "muted",
          "weight": 600
        },
        {
          "type": "group",
          "name": "Bottom navigation",
          "x": 0,
          "y": 751,
          "w": 390,
          "h": 93,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 390,
              "h": 1,
              "color": "line"
            },
            {
              "type": "group",
              "name": "Tab / 관심종목",
              "x": 0,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M4 5H20M4 12H20M4 19H14\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "관심종목",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 0,
              "centerText": true,
              "component": "Tab/0"
            },
            {
              "type": "group",
              "name": "Tab / 차트",
              "x": 97.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 4V20M3 9H7M3 15H7M12 2V17M10 5H14M10 11H14M19 8V22M17 12H21M17 18H21\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "차트",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "fg",
                  "weight": 600
                }
              ],
              "target": 1,
              "centerText": true,
              "component": "Tab/1"
            },
            {
              "type": "group",
              "name": "Tab / 자동매매",
              "x": 195,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M13 2L5 13H11L10 22L20 9H13Z\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "자동매매",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 3,
              "centerText": true,
              "component": "Tab/2"
            },
            {
              "type": "group",
              "name": "Tab / 매매일지",
              "x": 292.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 3H19V21H5ZM9 7H15M9 11H15M9 15H13\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "매매일지",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 4,
              "centerText": true,
              "component": "Tab/3"
            },
            {
              "type": "rect",
              "x": 132,
              "y": 80,
              "w": 126,
              "h": 4,
              "color": "fg"
            }
          ]
        },
        {
          "type": "text",
          "value": "72,800",
          "x": 24,
          "y": 126,
          "w": 342,
          "h": 51,
          "size": 34,
          "color": "fg",
          "weight": 500
        },
        {
          "type": "text",
          "value": "KRW",
          "x": 177,
          "y": 145,
          "w": 342,
          "h": 17,
          "size": 11,
          "color": "muted",
          "weight": 400
        },
        {
          "type": "text",
          "value": "▲ 1,200 (+1.68%)   ·   데모 시세",
          "x": 24,
          "y": 176,
          "w": 342,
          "h": 18,
          "size": 12,
          "color": "muted",
          "weight": 400
        },
        {
          "type": "group",
          "name": "Segment navigation",
          "x": 24,
          "y": 205,
          "w": 342,
          "h": 42,
          "children": [
            {
              "type": "text",
              "value": "차트",
              "x": 0,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "rect",
              "x": 0,
              "y": 40,
              "w": 98,
              "h": 2,
              "color": "fg"
            },
            {
              "type": "text",
              "value": "종목정보",
              "x": 114,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "뉴스",
              "x": 228,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "Candlestick chart",
          "x": 24,
          "y": 265,
          "w": 342,
          "h": 236,
          "children": [
            {
              "type": "svg",
              "x": 0,
              "y": 0,
              "w": 290,
              "h": 220,
              "body": "<path d=\"M0 32H290M0 85H290M0 138H290M0 175H290\" stroke=\"#252528\"/><path d=\"M9 109V136\" stroke=\"#6C6C74\"/><rect x=\"6\" y=\"118\" width=\"6\" height=\"8\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"6\" y=\"204\" width=\"6\" height=\"10\" fill=\"#4D4D53\"/><path d=\"M17 123.0818339997895V170.0863773899545\" stroke=\"#F5F5F2\"/><rect x=\"14\" y=\"132.0818339997895\" width=\"6\" height=\"28.004543390164997\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"14\" y=\"182.9632253798026\" width=\"6\" height=\"31.036774620197413\" fill=\"#4D4D53\"/><path d=\"M25 127.59061926691311V171.24027416368753\" stroke=\"#F5F5F2\"/><rect x=\"22\" y=\"136.5906192669131\" width=\"6\" height=\"24.649654896774422\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"22\" y=\"181.26756432935795\" width=\"6\" height=\"32.73243567064205\" fill=\"#4D4D53\"/><path d=\"M33 118.76018997212532V151.90733093250168\" stroke=\"#6C6C74\"/><rect x=\"30\" y=\"127.76018997212532\" width=\"6\" height=\"14.147140960376369\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"30\" y=\"200.47199979850333\" width=\"6\" height=\"13.528000201496681\" fill=\"#4D4D53\"/><path d=\"M41 100.91576884459325V149.68165027030764\" stroke=\"#F5F5F2\"/><rect x=\"38\" y=\"109.91576884459325\" width=\"6\" height=\"29.7658814257144\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"38\" y=\"185.0799376173018\" width=\"6\" height=\"28.920062382698205\" fill=\"#4D4D53\"/><path d=\"M49 83.85034510322558V122.81880954279171\" stroke=\"#F5F5F2\"/><rect x=\"46\" y=\"92.85034510322558\" width=\"6\" height=\"19.968464439566134\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"46\" y=\"180.02689313342154\" width=\"6\" height=\"33.97310686657846\" fill=\"#4D4D53\"/><path d=\"M57 76.8843786056115V115.68898280162108\" stroke=\"#6C6C74\"/><rect x=\"54\" y=\"85.8843786056115\" width=\"6\" height=\"19.80460419600957\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"54\" y=\"197.01461254502686\" width=\"6\" height=\"16.985387454973147\" fill=\"#4D4D53\"/><path d=\"M65 83.21213396680893V132.0054957920961\" stroke=\"#F5F5F2\"/><rect x=\"62\" y=\"92.21213396680893\" width=\"6\" height=\"29.793361825287146\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"62\" y=\"187.57533503203027\" width=\"6\" height=\"26.424664967969726\" fill=\"#4D4D53\"/><path d=\"M73 97.96408250671087V131.2979554733423\" stroke=\"#F5F5F2\"/><rect x=\"70\" y=\"106.96408250671087\" width=\"6\" height=\"14.333872966631436\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"70\" y=\"179.26604383441546\" width=\"6\" height=\"34.733956165584544\" fill=\"#4D4D53\"/><path d=\"M81 111.16069300468138V154.68241243365824\" stroke=\"#6C6C74\"/><rect x=\"78\" y=\"120.16069300468138\" width=\"6\" height=\"24.521719428976876\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"78\" y=\"193.69703786895607\" width=\"6\" height=\"20.302962131043913\" fill=\"#4D4D53\"/><path d=\"M89 113.7658814257144V160.8506769417222\" stroke=\"#F5F5F2\"/><rect x=\"86\" y=\"122.7658814257144\" width=\"6\" height=\"28.08479551600781\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"86\" y=\"190.39947222776576\" width=\"6\" height=\"23.600527772234244\" fill=\"#4D4D53\"/><path d=\"M97 103.16817824361875V130.36290704800763\" stroke=\"#F5F5F2\"/><rect x=\"94\" y=\"112.16817824361875\" width=\"6\" height=\"8.194728804388886\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"94\" y=\"179.0002448362324\" width=\"6\" height=\"34.99975516376759\" fill=\"#4D4D53\"/><path d=\"M105 84.7648108130944V131.68753477724013\" stroke=\"#6C6C74\"/><rect x=\"102\" y=\"93.7648108130944\" width=\"6\" height=\"27.922723964145725\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"102\" y=\"190.58567704998913\" width=\"6\" height=\"23.414322950010874\" fill=\"#4D4D53\"/><path d=\"M113 68.68781768011563V112.4641035906669\" stroke=\"#F5F5F2\"/><rect x=\"110\" y=\"77.68781768011563\" width=\"6\" height=\"24.776285910551263\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"110\" y=\"193.49582407933397\" width=\"6\" height=\"20.50417592066602\" fill=\"#4D4D53\"/><path d=\"M121 63.65808995867103V96.61801730144414\" stroke=\"#F5F5F2\"/><rect x=\"118\" y=\"72.65808995867103\" width=\"6\" height=\"13.959927342773119\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"118\" y=\"179.23481610762823\" width=\"6\" height=\"34.76518389237176\" fill=\"#4D4D53\"/><path d=\"M129 71.69539580399044V120.43209153403339\" stroke=\"#6C6C74\"/><rect x=\"126\" y=\"80.69539580399044\" width=\"6\" height=\"29.73669573004296\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"126\" y=\"187.74280399607207\" width=\"6\" height=\"26.25719600392792\" fill=\"#4D4D53\"/><path d=\"M137 86.89321615223385V126.02460313955103\" stroke=\"#F5F5F2\"/><rect x=\"134\" y=\"95.89321615223385\" width=\"6\" height=\"20.131386987317192\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"134\" y=\"196.80241708337337\" width=\"6\" height=\"17.197582916626633\" fill=\"#4D4D53\"/><path d=\"M145 99.00155992684293V137.64137902148346\" stroke=\"#F5F5F2\"/><rect x=\"142\" y=\"108.00155992684293\" width=\"6\" height=\"19.639819094640522\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"142\" y=\"179.96506270301109\" width=\"6\" height=\"34.03493729698892\" fill=\"#4D4D53\"/><path d=\"M153 99.6444710840841V148.46360585983265\" stroke=\"#6C6C74\"/><rect x=\"150\" y=\"108.6444710840841\" width=\"6\" height=\"29.819134775748548\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"150\" y=\"185.2253188307081\" width=\"6\" height=\"28.774681169291902\" fill=\"#4D4D53\"/><path d=\"M161 87.40077115478356V120.92087988639003\" stroke=\"#F5F5F2\"/><rect x=\"158\" y=\"96.40077115478356\" width=\"6\" height=\"14.520108731606477\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"158\" y=\"200.2530697584262\" width=\"6\" height=\"13.746930241573809\" fill=\"#4D4D53\"/><path d=\"M169 68.66612703336857V112.05861656391424\" stroke=\"#F5F5F2\"/><rect x=\"166\" y=\"77.66612703336857\" width=\"6\" height=\"24.392489530545674\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"166\" y=\"181.1763687318093\" width=\"6\" height=\"32.823631268190695\" fill=\"#4D4D53\"/><path d=\"M177 53.77352526120691V100.93699931535086\" stroke=\"#6C6C74\"/><rect x=\"174\" y=\"62.77352526120691\" width=\"6\" height=\"28.163474054143943\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"174\" y=\"183.0836090365986\" width=\"6\" height=\"30.9163909634014\" fill=\"#4D4D53\"/><path d=\"M185 50.72542104580127V78.11486339812036\" stroke=\"#F5F5F2\"/><rect x=\"182\" y=\"59.72542104580127\" width=\"6\" height=\"8.389442352319099\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"182\" y=\"203.7787172677399\" width=\"6\" height=\"10.221282732260097\" fill=\"#4D4D53\"/><path d=\"M193 60.339556314418346V107.17889996269216\" stroke=\"#F5F5F2\"/><rect x=\"190\" y=\"69.33955631441835\" width=\"6\" height=\"27.839343648273804\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"190\" y=\"182.84448989562074\" width=\"6\" height=\"31.155510104379267\" fill=\"#4D4D53\"/><path d=\"M201 75.75292843403777V119.65453098315844\" stroke=\"#6C6C74\"/><rect x=\"198\" y=\"84.75292843403777\" width=\"6\" height=\"24.90160254912067\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"198\" y=\"181.36054094983442\" width=\"6\" height=\"32.6394590501656\" fill=\"#4D4D53\"/><path d=\"M209 86.5847955160078V119.35704229749423\" stroke=\"#F5F5F2\"/><rect x=\"206\" y=\"95.5847955160078\" width=\"6\" height=\"13.772246781486434\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"206\" y=\"200.69120624755567\" width=\"6\" height=\"13.308793752444325\" fill=\"#4D4D53\"/><path d=\"M217 85.23349514969931V133.93930217458998\" stroke=\"#F5F5F2\"/><rect x=\"214\" y=\"94.23349514969931\" width=\"6\" height=\"29.705807024890678\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"214\" y=\"184.93603873800993\" width=\"6\" height=\"29.06396126199007\" fill=\"#4D4D53\"/><path d=\"M225 71.48751081640867V110.78086989114423\" stroke=\"#6C6C74\"/><rect x=\"222\" y=\"80.48751081640867\" width=\"6\" height=\"20.29335907473556\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"222\" y=\"180.09060178988742\" width=\"6\" height=\"33.90939821011258\" fill=\"#4D4D53\"/><path d=\"M233 52.65377497132841V91.12789701724047\" stroke=\"#F5F5F2\"/><rect x=\"230\" y=\"61.65377497132841\" width=\"6\" height=\"19.47412204591206\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"230\" y=\"197.2273552923033\" width=\"6\" height=\"16.772644707696728\" fill=\"#4D4D53\"/><path d=\"M241 39.125381865720115V87.96858012357993\" stroke=\"#F5F5F2\"/><rect x=\"238\" y=\"48.125381865720115\" width=\"6\" height=\"29.843198257859818\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"238\" y=\"187.4091528946758\" width=\"6\" height=\"26.590847105324187\" fill=\"#4D4D53\"/><path d=\"M249 38.077276035854275V71.78310970010304\" stroke=\"#6C6C74\"/><rect x=\"246\" y=\"47.077276035854275\" width=\"6\" height=\"14.705833664248768\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"246\" y=\"179.29920939767845\" width=\"6\" height=\"34.70079060232155\" fill=\"#4D4D53\"/><path d=\"M257 49.11402722569612V92.37600255197903\" stroke=\"#F5F5F2\"/><rect x=\"254\" y=\"58.11402722569612\" width=\"6\" height=\"24.261975326282904\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"254\" y=\"193.89905886692338\" width=\"6\" height=\"20.100941133076624\" fill=\"#4D4D53\"/><path d=\"M265 64.50969307405856V111.75026591438795\" stroke=\"#F5F5F2\"/><rect x=\"262\" y=\"73.50969307405856\" width=\"6\" height=\"28.240572840329392\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"262\" y=\"190.21433296895773\" width=\"6\" height=\"23.785667031042266\" fill=\"#4D4D53\"/><path d=\"M273 73.89427207883935V101.47839746736662\" stroke=\"#6C6C74\"/><rect x=\"270\" y=\"82.89427207883935\" width=\"6\" height=\"8.58412538852727\" fill=\"#0A0A0B\" stroke=\"#6C6C74\"/><rect x=\"270\" y=\"179.0022034973183\" width=\"6\" height=\"34.99779650268168\" fill=\"#4D4D53\"/><path d=\"M281 70.5440073563159V117.29841633148031\" stroke=\"#F5F5F2\"/><rect x=\"278\" y=\"79.5440073563159\" width=\"6\" height=\"27.75440897516441\" fill=\"#F5F5F2\" stroke=\"#F5F5F2\"/><rect x=\"278\" y=\"190.7729328469994\" width=\"6\" height=\"23.227067153000597\" fill=\"#4D4D53\"/><path d=\"M0 142C65 132 90 159 133 111S213 129 283 69\" stroke=\"#92929A\" fill=\"none\" stroke-width=\"1.4\"/>"
            },
            {
              "type": "text",
              "value": "74,000",
              "x": 296,
              "y": 23,
              "w": 46,
              "h": 14,
              "size": 9,
              "color": "quiet",
              "weight": 400
            },
            {
              "type": "text",
              "value": "72,800",
              "x": 296,
              "y": 77,
              "w": 46,
              "h": 14,
              "size": 9,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "71,000",
              "x": 296,
              "y": 130,
              "w": 46,
              "h": 14,
              "size": 9,
              "color": "quiet",
              "weight": 400
            },
            {
              "type": "text",
              "value": "09:00",
              "x": 0,
              "y": 219,
              "w": 342,
              "h": 15,
              "size": 10,
              "color": "quiet",
              "weight": 400
            },
            {
              "type": "text",
              "value": "12:00",
              "x": 132,
              "y": 219,
              "w": 342,
              "h": 15,
              "size": 10,
              "color": "quiet",
              "weight": 400
            },
            {
              "type": "text",
              "value": "15:30",
              "x": 254,
              "y": 219,
              "w": 342,
              "h": 15,
              "size": 10,
              "color": "quiet",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "Segment navigation",
          "x": 24,
          "y": 506,
          "w": 342,
          "h": 42,
          "children": [
            {
              "type": "text",
              "value": "1분",
              "x": 0,
              "y": 6,
              "w": 68.4,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "5분",
              "x": 68.4,
              "y": 6,
              "w": 68.4,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "15분",
              "x": 136.8,
              "y": 6,
              "w": 68.4,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "rect",
              "x": 136.8,
              "y": 40,
              "w": 52.400000000000006,
              "h": 2,
              "color": "fg"
            },
            {
              "type": "text",
              "value": "1시간",
              "x": 205.2,
              "y": 6,
              "w": 68.4,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "1일",
              "x": 273.6,
              "y": 6,
              "w": 68.4,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "AI forecast",
          "x": 24,
          "y": 563,
          "w": 342,
          "h": 103,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 103,
              "color": "panel"
            },
            {
              "type": "text",
              "value": "PILOT AI",
              "x": 14,
              "y": 10,
              "w": 342,
              "h": 15,
              "size": 10,
              "color": "muted",
              "weight": 600
            },
            {
              "type": "text",
              "value": "관망",
              "x": 14,
              "y": 32,
              "w": 100,
              "h": 35,
              "size": 23,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "다음 1시간 상승 가능성  62%",
              "x": 105,
              "y": 38,
              "w": 222,
              "h": 18,
              "size": 12,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "거래량 증가 · 단기 저항선 근접",
              "x": 14,
              "y": 70,
              "w": 310,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            }
          ]
        },
        {
          "type": "text",
          "value": "예시 분석 · 예측은 수익을 보장하지 않습니다.",
          "x": 24,
          "y": 675,
          "w": 342,
          "h": 15,
          "size": 10,
          "color": "quiet",
          "weight": 400
        },
        {
          "type": "group",
          "name": "매수 전 점검하기  →",
          "x": 24,
          "y": 697,
          "w": 342,
          "h": 48,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 48,
              "color": "fg"
            },
            {
              "type": "text",
              "value": "매수 전 점검하기  →",
              "x": 16,
              "y": 13,
              "w": 310,
              "h": 21,
              "size": 14,
              "color": "bg",
              "weight": 600
            }
          ],
          "target": 2,
          "component": "Button/primary"
        }
      ]
    },
    {
      "name": "03 · 거래 전 점검",
      "w": 390,
      "h": 844,
      "children": [
        {
          "type": "text",
          "value": "9:41",
          "x": 24,
          "y": 14,
          "w": 342,
          "h": 20,
          "size": 13,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "svg",
          "x": 304,
          "y": 18,
          "w": 62,
          "h": 12,
          "body": "<path d=\"M1 10V7H4V10ZM7 10V5H10V10ZM13 10V2H16V10Z\" fill=\"#F5F5F2\"/><path d=\"M22 3Q29 -2 36 3M25 6Q29 3 33 6\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\"/><rect x=\"43\" y=\"1\" width=\"17\" height=\"9\" fill=\"none\" stroke=\"#F5F5F2\"/><rect x=\"45\" y=\"3\" width=\"12\" height=\"5\" fill=\"#F5F5F2\"/>"
        },
        {
          "type": "text",
          "value": "PRE-TRADE / 감정을 점검하다",
          "x": 24,
          "y": 55,
          "w": 342,
          "h": 15,
          "size": 10,
          "color": "muted",
          "weight": 600
        },
        {
          "type": "text",
          "value": "잠깐, 계획된 매수인가요?",
          "x": 24,
          "y": 76,
          "w": 342,
          "h": 41,
          "size": 24,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "group",
          "name": "Back",
          "x": 326,
          "y": 64,
          "w": 40,
          "h": 44,
          "children": [
            {
              "type": "svg",
              "x": 8,
              "y": 10,
              "w": 24,
              "h": 24,
              "body": "<path d=\"M15 4L7 12L15 20\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
            }
          ],
          "target": 1
        },
        {
          "type": "group",
          "name": "Bottom navigation",
          "x": 0,
          "y": 751,
          "w": 390,
          "h": 93,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 390,
              "h": 1,
              "color": "line"
            },
            {
              "type": "group",
              "name": "Tab / 관심종목",
              "x": 0,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M4 5H20M4 12H20M4 19H14\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "관심종목",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 0,
              "centerText": true,
              "component": "Tab/0"
            },
            {
              "type": "group",
              "name": "Tab / 차트",
              "x": 97.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 4V20M3 9H7M3 15H7M12 2V17M10 5H14M10 11H14M19 8V22M17 12H21M17 18H21\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "차트",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "fg",
                  "weight": 600
                }
              ],
              "target": 1,
              "centerText": true,
              "component": "Tab/1"
            },
            {
              "type": "group",
              "name": "Tab / 자동매매",
              "x": 195,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M13 2L5 13H11L10 22L20 9H13Z\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "자동매매",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 3,
              "centerText": true,
              "component": "Tab/2"
            },
            {
              "type": "group",
              "name": "Tab / 매매일지",
              "x": 292.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 3H19V21H5ZM9 7H15M9 11H15M9 15H13\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "매매일지",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 4,
              "centerText": true,
              "component": "Tab/3"
            },
            {
              "type": "rect",
              "x": 132,
              "y": 80,
              "w": 126,
              "h": 4,
              "color": "fg"
            }
          ]
        },
        {
          "type": "group",
          "name": "Behavior alert",
          "x": 24,
          "y": 135,
          "w": 342,
          "h": 141,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 141,
              "color": "panel"
            },
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 3,
              "h": 141,
              "color": "fg"
            },
            {
              "type": "text",
              "value": "!   급등 추격 가능성",
              "x": 16,
              "y": 15,
              "w": 310,
              "h": 24,
              "size": 16,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "최근 30분 동안 가격이 4.2% 상승했습니다.",
              "x": 16,
              "y": 48,
              "w": 310,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "매수 화면을 3회 열었어요. 진입 근거를",
              "x": 16,
              "y": 71,
              "w": 310,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "한 번 더 확인해 보세요.",
              "x": 16,
              "y": 94,
              "w": 310,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "행동 감지 예시 · FOMO",
              "x": 16,
              "y": 118,
              "w": 310,
              "h": 15,
              "size": 10,
              "color": "quiet",
              "weight": 400
            }
          ]
        },
        {
          "type": "text",
          "value": "주문 요약",
          "x": 24,
          "y": 298,
          "w": 342,
          "h": 20,
          "size": 13,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "group",
          "name": "Order summary",
          "x": 24,
          "y": 327,
          "w": 342,
          "h": 61,
          "children": [
            {
              "type": "text",
              "value": "삼성전자  ·  지정가",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "10주 × 72,800원",
              "x": 0,
              "y": 25,
              "w": 342,
              "h": 30,
              "size": 20,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "728,000원",
              "x": 235,
              "y": 27,
              "w": 107,
              "h": 21,
              "size": 14,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "rect",
          "x": 24,
          "y": 401,
          "w": 342,
          "h": 1,
          "color": "line"
        },
        {
          "type": "text",
          "value": "리스크 가드",
          "x": 24,
          "y": 419,
          "w": 342,
          "h": 20,
          "size": 13,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "group",
          "name": "1회 주문한도",
          "x": 24,
          "y": 453,
          "w": 342,
          "h": 30,
          "children": [
            {
              "type": "text",
              "value": "1회 주문한도",
              "x": 0,
              "y": 3,
              "w": 150,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "100만원 이내  /  통과",
              "x": 164,
              "y": 3,
              "w": 178,
              "h": 17,
              "size": 11,
              "color": "fg",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "일 손실한도",
          "x": 24,
          "y": 488,
          "w": 342,
          "h": 30,
          "children": [
            {
              "type": "text",
              "value": "일 손실한도",
              "x": 0,
              "y": 3,
              "w": 150,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "30만원 이내  /  통과",
              "x": 164,
              "y": 3,
              "w": 178,
              "h": 17,
              "size": 11,
              "color": "fg",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "중복주문·거래 빈도",
          "x": 24,
          "y": 523,
          "w": 342,
          "h": 30,
          "children": [
            {
              "type": "text",
              "value": "중복주문·거래 빈도",
              "x": 0,
              "y": 3,
              "w": 150,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "중복 없음  /  통과",
              "x": 164,
              "y": 3,
              "w": 178,
              "h": 17,
              "size": 11,
              "color": "fg",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "Reason field",
          "x": 24,
          "y": 571,
          "w": 342,
          "h": 73,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 73,
              "color": "panel"
            },
            {
              "type": "text",
              "value": "나의 진입 근거",
              "x": 14,
              "y": 9,
              "w": 342,
              "h": 15,
              "size": 10,
              "color": "muted",
              "weight": 500
            },
            {
              "type": "text",
              "value": "계획한 지지선 도달 후 분할 매수",
              "x": 14,
              "y": 33,
              "w": 312,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 400
            }
          ]
        },
        {
          "type": "text",
          "value": "점검 후에도 주문은 직접 확인해야 합니다.",
          "x": 24,
          "y": 660,
          "w": 342,
          "h": 17,
          "size": 11,
          "color": "muted",
          "weight": 400
        },
        {
          "type": "group",
          "name": "모의주문 확인으로  →",
          "x": 24,
          "y": 693,
          "w": 342,
          "h": 48,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 48,
              "color": "fg"
            },
            {
              "type": "text",
              "value": "모의주문 확인으로  →",
              "x": 16,
              "y": 13,
              "w": 310,
              "h": 21,
              "size": 14,
              "color": "bg",
              "weight": 600
            }
          ],
          "target": 5,
          "component": "Button/primary"
        }
      ]
    },
    {
      "name": "04 · 자동매매",
      "w": 390,
      "h": 844,
      "children": [
        {
          "type": "text",
          "value": "9:41",
          "x": 24,
          "y": 14,
          "w": 342,
          "h": 20,
          "size": 13,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "svg",
          "x": 304,
          "y": 18,
          "w": 62,
          "h": 12,
          "body": "<path d=\"M1 10V7H4V10ZM7 10V5H10V10ZM13 10V2H16V10Z\" fill=\"#F5F5F2\"/><path d=\"M22 3Q29 -2 36 3M25 6Q29 3 33 6\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\"/><rect x=\"43\" y=\"1\" width=\"17\" height=\"9\" fill=\"none\" stroke=\"#F5F5F2\"/><rect x=\"45\" y=\"3\" width=\"12\" height=\"5\" fill=\"#F5F5F2\"/>"
        },
        {
          "type": "text",
          "value": "AUTOPILOT / 원칙을 실행하다",
          "x": 24,
          "y": 55,
          "w": 342,
          "h": 15,
          "size": 10,
          "color": "muted",
          "weight": 600
        },
        {
          "type": "text",
          "value": "나의 자동매매",
          "x": 24,
          "y": 76,
          "w": 342,
          "h": 41,
          "size": 27,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "text",
          "value": "모의",
          "x": 326,
          "y": 85,
          "w": 40,
          "h": 17,
          "size": 11,
          "color": "muted",
          "weight": 600
        },
        {
          "type": "group",
          "name": "Bottom navigation",
          "x": 0,
          "y": 751,
          "w": 390,
          "h": 93,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 390,
              "h": 1,
              "color": "line"
            },
            {
              "type": "group",
              "name": "Tab / 관심종목",
              "x": 0,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M4 5H20M4 12H20M4 19H14\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "관심종목",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 0,
              "centerText": true,
              "component": "Tab/0"
            },
            {
              "type": "group",
              "name": "Tab / 차트",
              "x": 97.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 4V20M3 9H7M3 15H7M12 2V17M10 5H14M10 11H14M19 8V22M17 12H21M17 18H21\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "차트",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 1,
              "centerText": true,
              "component": "Tab/1"
            },
            {
              "type": "group",
              "name": "Tab / 자동매매",
              "x": 195,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M13 2L5 13H11L10 22L20 9H13Z\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "자동매매",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "fg",
                  "weight": 600
                }
              ],
              "target": 3,
              "centerText": true,
              "component": "Tab/2"
            },
            {
              "type": "group",
              "name": "Tab / 매매일지",
              "x": 292.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 3H19V21H5ZM9 7H15M9 11H15M9 15H13\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "매매일지",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 4,
              "centerText": true,
              "component": "Tab/3"
            },
            {
              "type": "rect",
              "x": 132,
              "y": 80,
              "w": 126,
              "h": 4,
              "color": "fg"
            }
          ]
        },
        {
          "type": "group",
          "name": "Account balance",
          "x": 24,
          "y": 133,
          "w": 342,
          "h": 110,
          "children": [
            {
              "type": "text",
              "value": "모의계좌 평가금액",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "10,248,600",
              "x": 0,
              "y": 25,
              "w": 342,
              "h": 48,
              "size": 32,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "KRW",
              "x": 220,
              "y": 44,
              "w": 342,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "누적 손익  +248,600원  (+2.49%)",
              "x": 0,
              "y": 78,
              "w": 342,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "Segment navigation",
          "x": 24,
          "y": 258,
          "w": 342,
          "h": 42,
          "children": [
            {
              "type": "text",
              "value": "운용 중  1",
              "x": 0,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "rect",
              "x": 0,
              "y": 40,
              "w": 98,
              "h": 2,
              "color": "fg"
            },
            {
              "type": "text",
              "value": "전략 목록",
              "x": 114,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "백테스트",
              "x": 228,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "Active strategy",
          "x": 24,
          "y": 319,
          "w": 342,
          "h": 171,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 171,
              "color": "panel"
            },
            {
              "type": "text",
              "value": "01 / ACTIVE",
              "x": 16,
              "y": 15,
              "w": 342,
              "h": 15,
              "size": 10,
              "color": "muted",
              "weight": 600
            },
            {
              "type": "text",
              "value": "추세 추종 · 분할 진입",
              "x": 16,
              "y": 41,
              "w": 310,
              "h": 29,
              "size": 19,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "삼성전자 · SK하이닉스",
              "x": 16,
              "y": 72,
              "w": 310,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "rect",
              "x": 16,
              "y": 102,
              "w": 310,
              "h": 1,
              "color": "line"
            },
            {
              "type": "text",
              "value": "오늘 주문",
              "x": 16,
              "y": 119,
              "w": 140,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "2건",
              "x": 16,
              "y": 138,
              "w": 140,
              "h": 24,
              "size": 16,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "전략 수익률",
              "x": 184,
              "y": 119,
              "w": 140,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "+1.82%",
              "x": 184,
              "y": 138,
              "w": 140,
              "h": 24,
              "size": 16,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "text",
          "value": "위험관리 설정",
          "x": 24,
          "y": 516,
          "w": 342,
          "h": 21,
          "size": 14,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "group",
          "name": "1회 주문한도",
          "x": 24,
          "y": 552,
          "w": 342,
          "h": 26,
          "children": [
            {
              "type": "text",
              "value": "1회 주문한도",
              "x": 0,
              "y": 0,
              "w": 180,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "1,000,000원",
              "x": 210,
              "y": 0,
              "w": 132,
              "h": 18,
              "size": 12,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "group",
          "name": "일 손실한도",
          "x": 24,
          "y": 582,
          "w": 342,
          "h": 26,
          "children": [
            {
              "type": "text",
              "value": "일 손실한도",
              "x": 0,
              "y": 0,
              "w": 180,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "300,000원",
              "x": 210,
              "y": 0,
              "w": 132,
              "h": 18,
              "size": 12,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "group",
          "name": "연속 손실 후 쿨다운",
          "x": 24,
          "y": 612,
          "w": 342,
          "h": 26,
          "children": [
            {
              "type": "text",
              "value": "연속 손실 후 쿨다운",
              "x": 0,
              "y": 0,
              "w": 180,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "30분",
              "x": 210,
              "y": 0,
              "w": 132,
              "h": 18,
              "size": 12,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "group",
          "name": "중복주문 차단",
          "x": 24,
          "y": 642,
          "w": 342,
          "h": 26,
          "children": [
            {
              "type": "text",
              "value": "중복주문 차단",
              "x": 0,
              "y": 0,
              "w": 180,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "사용 중",
              "x": 210,
              "y": 0,
              "w": 132,
              "h": 18,
              "size": 12,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "group",
          "name": "전체 자동매매 중지",
          "x": 24,
          "y": 687,
          "w": 342,
          "h": 48,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 48,
              "color": "panel"
            },
            {
              "type": "text",
              "value": "전체 자동매매 중지",
              "x": 16,
              "y": 13,
              "w": 310,
              "h": 21,
              "size": 14,
              "color": "fg",
              "weight": 600
            }
          ],
          "target": null,
          "component": "Button/secondary"
        },
        {
          "type": "text",
          "value": "데모 상태 · 실계좌에 연결되지 않았습니다.",
          "x": 24,
          "y": 738,
          "w": 342,
          "h": 14,
          "size": 9,
          "color": "quiet",
          "weight": 400
        }
      ]
    },
    {
      "name": "05 · 매매일지와 피드백",
      "w": 390,
      "h": 844,
      "children": [
        {
          "type": "text",
          "value": "9:41",
          "x": 24,
          "y": 14,
          "w": 342,
          "h": 20,
          "size": 13,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "svg",
          "x": 304,
          "y": 18,
          "w": 62,
          "h": 12,
          "body": "<path d=\"M1 10V7H4V10ZM7 10V5H10V10ZM13 10V2H16V10Z\" fill=\"#F5F5F2\"/><path d=\"M22 3Q29 -2 36 3M25 6Q29 3 33 6\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\"/><rect x=\"43\" y=\"1\" width=\"17\" height=\"9\" fill=\"none\" stroke=\"#F5F5F2\"/><rect x=\"45\" y=\"3\" width=\"12\" height=\"5\" fill=\"#F5F5F2\"/>"
        },
        {
          "type": "text",
          "value": "JOURNAL / 판단을 기록하다",
          "x": 24,
          "y": 55,
          "w": 342,
          "h": 15,
          "size": 10,
          "color": "muted",
          "weight": 600
        },
        {
          "type": "text",
          "value": "거래를 돌아보다",
          "x": 24,
          "y": 76,
          "w": 342,
          "h": 41,
          "size": 27,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "text",
          "value": "모의",
          "x": 326,
          "y": 85,
          "w": 40,
          "h": 17,
          "size": 11,
          "color": "muted",
          "weight": 600
        },
        {
          "type": "group",
          "name": "Bottom navigation",
          "x": 0,
          "y": 751,
          "w": 390,
          "h": 93,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 390,
              "h": 1,
              "color": "line"
            },
            {
              "type": "group",
              "name": "Tab / 관심종목",
              "x": 0,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M4 5H20M4 12H20M4 19H14\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "관심종목",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 0,
              "centerText": true,
              "component": "Tab/0"
            },
            {
              "type": "group",
              "name": "Tab / 차트",
              "x": 97.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 4V20M3 9H7M3 15H7M12 2V17M10 5H14M10 11H14M19 8V22M17 12H21M17 18H21\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "차트",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 1,
              "centerText": true,
              "component": "Tab/1"
            },
            {
              "type": "group",
              "name": "Tab / 자동매매",
              "x": 195,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M13 2L5 13H11L10 22L20 9H13Z\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "자동매매",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 3,
              "centerText": true,
              "component": "Tab/2"
            },
            {
              "type": "group",
              "name": "Tab / 매매일지",
              "x": 292.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 3H19V21H5ZM9 7H15M9 11H15M9 15H13\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "매매일지",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "fg",
                  "weight": 600
                }
              ],
              "target": 4,
              "centerText": true,
              "component": "Tab/3"
            },
            {
              "type": "rect",
              "x": 132,
              "y": 80,
              "w": 126,
              "h": 4,
              "color": "fg"
            }
          ]
        },
        {
          "type": "group",
          "name": "Segment navigation",
          "x": 24,
          "y": 130,
          "w": 342,
          "h": 42,
          "children": [
            {
              "type": "text",
              "value": "이번 주",
              "x": 0,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "rect",
              "x": 0,
              "y": 40,
              "w": 98,
              "h": 2,
              "color": "fg"
            },
            {
              "type": "text",
              "value": "이번 달",
              "x": 114,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "전체",
              "x": 228,
              "y": 6,
              "w": 114,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "Weekly stats",
          "x": 24,
          "y": 194,
          "w": 342,
          "h": 90,
          "children": [
            {
              "type": "text",
              "value": "원칙 준수율",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "86%",
              "x": 0,
              "y": 22,
              "w": 170,
              "h": 60,
              "size": 40,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "rect",
              "x": 170,
              "y": 4,
              "w": 1,
              "h": 70,
              "color": "line"
            },
            {
              "type": "text",
              "value": "지난주 대비",
              "x": 194,
              "y": 5,
              "w": 148,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "+12%p",
              "x": 194,
              "y": 27,
              "w": 148,
              "h": 38,
              "size": 25,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "모의거래 14건 기준",
              "x": 194,
              "y": 66,
              "w": 148,
              "h": 15,
              "size": 10,
              "color": "quiet",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "AI comparison",
          "x": 24,
          "y": 311,
          "w": 342,
          "h": 130,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 130,
              "color": "panel"
            },
            {
              "type": "text",
              "value": "AI 판단과 나의 거래",
              "x": 16,
              "y": 14,
              "w": 310,
              "h": 21,
              "size": 14,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "동일 기간 · 동일 초기 자금",
              "x": 16,
              "y": 40,
              "w": 310,
              "h": 15,
              "size": 10,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "나의 수익률",
              "x": 16,
              "y": 66,
              "w": 140,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "+2.49%",
              "x": 16,
              "y": 87,
              "w": 140,
              "h": 35,
              "size": 23,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "AI 모의전략",
              "x": 185,
              "y": 66,
              "w": 140,
              "h": 17,
              "size": 11,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "+3.12%",
              "x": 185,
              "y": 87,
              "w": 140,
              "h": 35,
              "size": 23,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "text",
          "value": "최근 매매",
          "x": 24,
          "y": 465,
          "w": 342,
          "h": 21,
          "size": 14,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "text",
          "value": "전체 보기 →",
          "x": 294,
          "y": 468,
          "w": 80,
          "h": 17,
          "size": 11,
          "color": "muted",
          "weight": 400
        },
        {
          "type": "group",
          "name": "Journal entry",
          "x": 24,
          "y": 507,
          "w": 342,
          "h": 82,
          "children": [
            {
              "type": "text",
              "value": "09.14  /  삼성전자",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 21,
              "size": 14,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "매수 10주 · 계획한 지지선 도달",
              "x": 0,
              "y": 25,
              "w": 342,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "계획 준수",
              "x": 263,
              "y": 2,
              "w": 79,
              "h": 17,
              "size": 11,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "rect",
              "x": 0,
              "y": 69,
              "w": 342,
              "h": 1,
              "color": "line"
            }
          ]
        },
        {
          "type": "group",
          "name": "Journal entry",
          "x": 24,
          "y": 591,
          "w": 342,
          "h": 72,
          "children": [
            {
              "type": "text",
              "value": "09.12  /  SK하이닉스",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 21,
              "size": 14,
              "color": "fg",
              "weight": 600
            },
            {
              "type": "text",
              "value": "매도 5주 · 손실 후 조기 청산",
              "x": 0,
              "y": 25,
              "w": 342,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "복기 필요",
              "x": 263,
              "y": 2,
              "w": 79,
              "h": 17,
              "size": 11,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "group",
          "name": "Feedback",
          "x": 24,
          "y": 678,
          "w": 342,
          "h": 57,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 2,
              "h": 50,
              "color": "fg"
            },
            {
              "type": "text",
              "value": "PILOT 피드백",
              "x": 14,
              "y": 0,
              "w": 342,
              "h": 15,
              "size": 10,
              "color": "muted",
              "weight": 600
            },
            {
              "type": "text",
              "value": "손절 기준을 주문 전에 정해 두세요.",
              "x": 14,
              "y": 23,
              "w": 325,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 500
            }
          ]
        }
      ]
    },
    {
      "name": "06 · 모의주문 최종 확인",
      "w": 390,
      "h": 844,
      "children": [
        {
          "type": "text",
          "value": "9:41",
          "x": 24,
          "y": 14,
          "w": 342,
          "h": 20,
          "size": 13,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "svg",
          "x": 304,
          "y": 18,
          "w": 62,
          "h": 12,
          "body": "<path d=\"M1 10V7H4V10ZM7 10V5H10V10ZM13 10V2H16V10Z\" fill=\"#F5F5F2\"/><path d=\"M22 3Q29 -2 36 3M25 6Q29 3 33 6\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\"/><rect x=\"43\" y=\"1\" width=\"17\" height=\"9\" fill=\"none\" stroke=\"#F5F5F2\"/><rect x=\"45\" y=\"3\" width=\"12\" height=\"5\" fill=\"#F5F5F2\"/>"
        },
        {
          "type": "text",
          "value": "PAPER ORDER / 최종 확인",
          "x": 24,
          "y": 55,
          "w": 342,
          "h": 15,
          "size": 10,
          "color": "muted",
          "weight": 600
        },
        {
          "type": "text",
          "value": "주문을 확인해 주세요",
          "x": 24,
          "y": 76,
          "w": 342,
          "h": 41,
          "size": 27,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "group",
          "name": "Back",
          "x": 326,
          "y": 64,
          "w": 40,
          "h": 44,
          "children": [
            {
              "type": "svg",
              "x": 8,
              "y": 10,
              "w": 24,
              "h": 24,
              "body": "<path d=\"M15 4L7 12L15 20\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
            }
          ],
          "target": 1
        },
        {
          "type": "group",
          "name": "Bottom navigation",
          "x": 0,
          "y": 751,
          "w": 390,
          "h": 93,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 390,
              "h": 1,
              "color": "line"
            },
            {
              "type": "group",
              "name": "Tab / 관심종목",
              "x": 0,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M4 5H20M4 12H20M4 19H14\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "관심종목",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 0,
              "centerText": true,
              "component": "Tab/0"
            },
            {
              "type": "group",
              "name": "Tab / 차트",
              "x": 97.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 4V20M3 9H7M3 15H7M12 2V17M10 5H14M10 11H14M19 8V22M17 12H21M17 18H21\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "차트",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "fg",
                  "weight": 600
                }
              ],
              "target": 1,
              "centerText": true,
              "component": "Tab/1"
            },
            {
              "type": "group",
              "name": "Tab / 자동매매",
              "x": 195,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M13 2L5 13H11L10 22L20 9H13Z\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "자동매매",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 3,
              "centerText": true,
              "component": "Tab/2"
            },
            {
              "type": "group",
              "name": "Tab / 매매일지",
              "x": 292.5,
              "y": 0,
              "w": 97.5,
              "h": 70,
              "children": [
                {
                  "type": "svg",
                  "x": 37,
                  "y": 14,
                  "w": 22,
                  "h": 22,
                  "body": "<path d=\"M5 3H19V21H5ZM9 7H15M9 11H15M9 15H13\" fill=\"none\" stroke=\"#797980\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
                },
                {
                  "type": "text",
                  "value": "매매일지",
                  "x": 0,
                  "y": 43,
                  "w": 97.5,
                  "h": 15,
                  "size": 10,
                  "color": "quiet",
                  "weight": 400
                }
              ],
              "target": 4,
              "centerText": true,
              "component": "Tab/3"
            },
            {
              "type": "rect",
              "x": 132,
              "y": 80,
              "w": 126,
              "h": 4,
              "color": "fg"
            }
          ]
        },
        {
          "type": "text",
          "value": "삼성전자",
          "x": 24,
          "y": 143,
          "w": 342,
          "h": 30,
          "size": 20,
          "color": "fg",
          "weight": 600
        },
        {
          "type": "text",
          "value": "005930 · KRX  /  모의 매수",
          "x": 24,
          "y": 175,
          "w": 342,
          "h": 18,
          "size": 12,
          "color": "muted",
          "weight": 400
        },
        {
          "type": "rect",
          "x": 24,
          "y": 211,
          "w": 342,
          "h": 1,
          "color": "line"
        },
        {
          "type": "text",
          "value": "예상 주문금액",
          "x": 24,
          "y": 236,
          "w": 342,
          "h": 18,
          "size": 12,
          "color": "muted",
          "weight": 400
        },
        {
          "type": "text",
          "value": "728,000",
          "x": 24,
          "y": 261,
          "w": 342,
          "h": 57,
          "size": 38,
          "color": "fg",
          "weight": 500
        },
        {
          "type": "text",
          "value": "KRW",
          "x": 194,
          "y": 283,
          "w": 342,
          "h": 17,
          "size": 11,
          "color": "muted",
          "weight": 400
        },
        {
          "type": "group",
          "name": "주문 유형",
          "x": 24,
          "y": 333,
          "w": 342,
          "h": 34,
          "children": [
            {
              "type": "text",
              "value": "주문 유형",
              "x": 0,
              "y": 4,
              "w": 160,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "지정가 매수",
              "x": 198,
              "y": 4,
              "w": 144,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "group",
          "name": "주문 가격",
          "x": 24,
          "y": 373,
          "w": 342,
          "h": 34,
          "children": [
            {
              "type": "text",
              "value": "주문 가격",
              "x": 0,
              "y": 4,
              "w": 160,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "72,800원",
              "x": 198,
              "y": 4,
              "w": 144,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "group",
          "name": "주문 수량",
          "x": 24,
          "y": 413,
          "w": 342,
          "h": 34,
          "children": [
            {
              "type": "text",
              "value": "주문 수량",
              "x": 0,
              "y": 4,
              "w": 160,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "10주",
              "x": 198,
              "y": 4,
              "w": 144,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "group",
          "name": "수수료",
          "x": 24,
          "y": 453,
          "w": 342,
          "h": 34,
          "children": [
            {
              "type": "text",
              "value": "수수료",
              "x": 0,
              "y": 4,
              "w": 160,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "모의거래 · 미반영",
              "x": 198,
              "y": 4,
              "w": 144,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "group",
          "name": "주문 후 예수금",
          "x": 24,
          "y": 493,
          "w": 342,
          "h": 34,
          "children": [
            {
              "type": "text",
              "value": "주문 후 예수금",
              "x": 0,
              "y": 4,
              "w": 160,
              "h": 20,
              "size": 13,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "9,272,000원",
              "x": 198,
              "y": 4,
              "w": 144,
              "h": 20,
              "size": 13,
              "color": "fg",
              "weight": 500
            }
          ]
        },
        {
          "type": "group",
          "name": "Final checklist",
          "x": 24,
          "y": 562,
          "w": 342,
          "h": 96,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 96,
              "color": "panel"
            },
            {
              "type": "svg",
              "x": 14,
              "y": 15,
              "w": 20,
              "h": 20,
              "body": "<path d=\"M5 12L10 17L20 6\" fill=\"none\" stroke=\"#F5F5F2\" stroke-width=\"1.5\" stroke-linejoin=\"miter\"/>"
            },
            {
              "type": "text",
              "value": "진입 근거와 위험 한도를 확인했습니다.",
              "x": 44,
              "y": 16,
              "w": 282,
              "h": 18,
              "size": 12,
              "color": "fg",
              "weight": 500
            },
            {
              "type": "text",
              "value": "실제 자금이 사용되지 않는 모의주문입니다.",
              "x": 16,
              "y": 52,
              "w": 310,
              "h": 18,
              "size": 12,
              "color": "muted",
              "weight": 400
            },
            {
              "type": "text",
              "value": "샘플 주문 · 체결 기능 없음",
              "x": 16,
              "y": 74,
              "w": 310,
              "h": 15,
              "size": 10,
              "color": "quiet",
              "weight": 400
            }
          ]
        },
        {
          "type": "group",
          "name": "모의 매수 확인 (데모)",
          "x": 24,
          "y": 692,
          "w": 342,
          "h": 48,
          "children": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 342,
              "h": 48,
              "color": "fg"
            },
            {
              "type": "text",
              "value": "모의 매수 확인 (데모)",
              "x": 16,
              "y": 13,
              "w": 310,
              "h": 21,
              "size": 14,
              "color": "bg",
              "weight": 600
            }
          ],
          "target": null,
          "component": "Button/primary"
        }
      ]
    }
  ]
};
// Local Figma development plugin. No network, account, or trading access.
async function main() {
  const fonts=await figma.listAvailableFontsAsync();
  const family=['Apple SD Gothic Neo','Pretendard','Noto Sans KR','Noto Sans CJK KR'].find(f=>fonts.some(v=>v.fontName.family===f));
  if(!family)throw new Error('Apple SD Gothic Neo, Pretendard 또는 Noto Sans KR 글꼴을 설치한 뒤 다시 실행해 주세요.');
  function choose(weight){const candidates=weight>=600?['SemiBold','Semibold','Bold','Medium','Regular']:weight>=500?['Medium','Regular']:['Regular','Medium'];return fonts.find(f=>f.fontName.family===family&&candidates.includes(f.fontName.style)&&f.fontName.style===candidates.find(v=>fonts.some(f=>f.fontName.family===family&&f.fontName.style===v))).fontName;}
  const fontMap={400:choose(400),500:choose(500),600:choose(600)};
  await Promise.all(Object.values(fontMap).map(f=>figma.loadFontAsync(f)));
  const page=figma.createPage();page.name='TradePilot / Client UI';await figma.setCurrentPageAsync(page);
  const rgb=hex=>({r:parseInt(hex.slice(1,3),16)/255,g:parseInt(hex.slice(3,5),16)/255,b:parseInt(hex.slice(5,7),16)/255});
  const collection=figma.variables.createVariableCollection('TradePilot / Monochrome');
  const vars={};
  for(const [name,value] of Object.entries(DESIGN.colors)){const v=figma.variables.createVariable('color/'+name,collection,'COLOR');v.scopes=['FRAME_FILL','SHAPE_FILL','TEXT_FILL','STROKE_COLOR'];v.setValueForMode(collection.defaultModeId,rgb(value));v.setVariableCodeSyntax('WEB','var(--tp-'+name+')');vars[name]=v;}
  function paint(key){return figma.variables.setBoundVariableForPaint({type:'SOLID',color:rgb(DESIGN.colors[key])},'color',vars[key]);}
  const links=[];const roots=[];
  async function make(d,parent,center=false){
    let n;
    if(d.type==='text'){
      n=figma.createText();n.fontName=fontMap[d.weight]||fontMap[400];n.fontSize=d.size;n.lineHeight={unit:'PIXELS',value:Math.ceil(d.size*1.5)};n.characters=d.value;n.fills=[paint(d.color)];n.textAutoResize='HEIGHT';n.resize(Math.max(1,Math.min(d.w,parent.width-d.x)),Math.ceil(d.size*1.5));if(center)n.textAlignHorizontal='CENTER';
    }else if(d.type==='rect'){n=figma.createRectangle();n.resize(d.w,d.h);n.fills=[paint(d.color)];
    }else if(d.type==='svg'){n=figma.createNodeFromSvg('<svg xmlns="http://www.w3.org/2000/svg" width="'+d.w+'" height="'+d.h+'" viewBox="0 0 '+(d.w<=24?24:d.w)+' '+(d.w<=24&&d.h<=24?24:d.h)+'">'+d.body+'</svg>');
    }else{
      n=figma.createFrame();n.resize(d.w,d.h);n.fills=[];n.clipsContent=false;
    }
    parent.appendChild(n);n.x=d.x;n.y=d.y;n.name=d.name||d.value|| (d.type==='svg'?'Chart / vector':'Divider');
    if(d.type==='group'){
      if(d.component&&d.component.startsWith('Button/')){
        n.layoutMode='HORIZONTAL';n.primaryAxisSizingMode='FIXED';n.counterAxisSizingMode='FIXED';n.counterAxisAlignItems='CENTER';n.paddingLeft=16;n.paddingRight=16;n.fills=[paint(d.component==='Button/primary'?'fg':'panel')];
        const label=d.children.find(c=>c.type==='text');const t=await make({...label,x:0,y:0,w:d.w-32},n);t.layoutSizingHorizontal='FILL';
      }else for(const child of d.children)await make(child,n,d.centerText);
    }
    if(d.target!==undefined&&d.target!==null)links.push([n,d.target]);
    return n;
  }
  for(let i=0;i<DESIGN.screens.length;i++){
    const s=DESIGN.screens[i];const root=figma.createFrame();page.appendChild(root);root.name=s.name;root.resize(s.w,s.h);root.x=200+(i%3)*450;root.y=200+Math.floor(i/3)*940;root.fills=[paint('bg')];root.clipsContent=true;roots.push(root);
    for(const d of s.children)await make(d,root);
  }
  for(const [node,target] of links)await node.setReactionsAsync([{trigger:{type:'ON_CLICK'},actions:[{type:'NODE',destinationId:roots[target].id,navigation:'NAVIGATE',transition:null}]}]);
  page.flowStartingPoints=[{nodeId:roots[0].id,name:'TradePilot · 모의투자'}];
  figma.viewport.scrollAndZoomIntoView(roots);
  const warnings=[];for(const root of roots)for(const t of root.findAll(n=>n.type==='TEXT'))if(t.height>Math.ceil(t.fontSize*1.5)+1)warnings.push(t.characters);
  figma.closePlugin('TradePilot 6개 화면 생성 완료'+(warnings.length?' · 줄바꿈 확인: '+warnings.length+'곳':''));
}
main().catch(error=>figma.closePlugin('TradePilot: '+error.message));
