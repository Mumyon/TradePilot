# TradePilot MVP 실행 안내

이 소스는 Flutter 모바일 앱과 FastAPI·PostgreSQL 모의투자 서버를 포함합니다. 실제 증권사 연결 및 실제 학습 모델은 포함하지 않습니다. 테스트 시세와 가상 자금으로 시연합니다.

## 1. 준비

권장 재현 환경은 macOS + Xcode + iOS Simulator입니다. Flutter SDK, Python 3.12, uv를 설치하고 `flutter doctor`에서 iOS 개발 환경을 확인하세요. SDK와 Python 가상환경은 용량 및 환경 차이 때문에 ZIP에 포함하지 않았습니다. 의존성은 `pubspec.lock`과 `uv.lock`에 기록되어 있습니다.

압축을 해제한 `TradePilot_MVP` 폴더에서 터미널을 여세요. 아래 명령은 각각 해당 폴더를 기준으로 시작합니다.

## 2. 서버 실행 — 터미널 1

```sh
cd server
uv sync --python 3.12 --frozen --group postgres-test
cd ..
chmod +x tool/start_demo_server.sh
./tool/start_demo_server.sh
```

로컬 시연 도구가 PostgreSQL을 준비하고 DB 마이그레이션을 적용한 뒤 서버를 실행합니다. Docker와 별도의 PostgreSQL 설치 없이 사용할 수 있습니다. 최초 설치에는 네트워크 연결이 필요합니다. `server/.demo/`에 시연 데이터가 저장되므로 정상 종료 후 다시 실행해도 계정과 기록을 유지합니다.

- 준비 상태: <http://127.0.0.1:18081/health/ready>
- API 문서: <http://127.0.0.1:18081/docs>
- 종료: 서버 터미널에서 `Ctrl+C`

이미 18081 포트를 사용 중인 서버가 있다면 중복 실행하지 마세요.

## 3. iPhone 시뮬레이터 앱 실행 — 터미널 2

Xcode에서 iOS 시뮬레이터 런타임을 설치한 뒤 다음을 실행하세요.

```sh
open -a Simulator
cd client
flutter pub get
flutter devices
```

출력된 iPhone 시뮬레이터 ID를 아래 `<SIMULATOR_ID>` 대신 입력하세요.

```sh
flutter run -d <SIMULATOR_ID> \
  --dart-define=DEMO_MODE=false \
  --dart-define=LOCAL_DEMO=true \
  --dart-define=API_BASE_URL=http://127.0.0.1:18081
```

`DEMO_MODE=false`는 실제 FastAPI에 연결한다는 뜻입니다. 서버의 거래는 여전히 가상 자금 기반 모의거래입니다. `LOCAL_DEMO=true`는 이 로컬 HTTP 시연 환경을 위한 설정입니다.

실물 iPhone의 `127.0.0.1`은 휴대전화 자신을 가리킵니다. 위 명령은 Mac에서 실행하는 iOS 시뮬레이터용이며, 실물 기기에는 별도의 접근 가능한 서버 주소와 HTTPS 구성이 필요합니다. macOS 데스크톱 앱 대상은 현재 소스에 포함되어 있지 않습니다.

## 4. 시연 순서

1. 앱에서 회원가입 후 로그인합니다. 기본 계정은 없으며, 본인이 만든 계정을 사용합니다. 비밀번호는 화면의 조건을 따릅니다.
2. 관심종목에서 삼성전자를 선택하여 테스트 시세·차트와 AI 대기 사유를 확인합니다.
3. 위험한도와 매매 계획을 저장합니다.
4. 삼성전자 1주·72,800원 매수를 입력하고 점검 결과와 주문 요약을 확인합니다.
5. 주문을 확정하고 다음 시세에서 모의 체결 여부를 확인합니다. 기본 쿨다운 때문에 같은 종목·방향 재주문은 일정 시간 제한될 수 있습니다.
6. 계좌와 매매일지를 열어 수수료·보유량·당시 점검 결과를 확인하고 복기 메모를 저장합니다.
7. 추가 기능은 전체 메뉴의 백테스트·모의 자동매매·CSV 등록에서 확인합니다. `server/examples/synthetic_5m.csv`는 실제 주가가 아닌 합성 예제입니다.

보고서의 계좌 화면에는 통합시험용 초기 보유량이 포함되어 있어 신규 회원의 기본 잔액과 다를 수 있습니다. 보고서의 행동 경고 화면도 통제된 합성 시나리오에서 캡처한 것으로, 신규 계정에서 같은 경고가 항상 나타나는 것은 아닙니다.

## 5. 테스트 재현

서버 폴더에서:

```sh
uv run --group postgres-test pytest -q
uv run ruff check .
```

클라이언트 폴더에서:

```sh
flutter analyze
flutter test
```

서버 테스트는 임시 PostgreSQL을 사용합니다. 모바일 네이티브 통합 테스트는 별도로 서버 시험 fixture와 기기 설정이 필요합니다. `server/tool/serve_integration.py`, `client/integration_test/`, `client/test_driver/`에 관련 코드가 있습니다.

## 6. Android 및 포함 범위

Android 소스도 포함되어 있으며 ARM64 디버그 APK 빌드를 확인했습니다. Android 기기에서의 화면·동작 검증은 별도입니다. Android 에뮬레이터에서 Mac의 서버에 접속할 때는 `127.0.0.1` 대신 `10.0.2.2`와 해당 테스트 환경의 네트워크 설정이 필요합니다.

실제 DB, 로그인 세션, 개인 `.env`, 인증서, SDK, 가상환경, 빌드 캐시는 제외했습니다. 원본 디자인 JSON은 디자인 일치 검증 테스트를 위해 포함했습니다. 이미지·폰트 등 프로젝트 자산의 출처와 라이선스는 각 자산의 안내를 따릅니다.
