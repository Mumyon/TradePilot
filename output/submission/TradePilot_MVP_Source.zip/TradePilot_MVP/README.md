# TradePilot MVP

실행 방법은 [RUN_MVP.md](RUN_MVP.md)를 참고하세요.

Flutter 모바일 앱과 FastAPI·PostgreSQL 모의투자 서버의 과제 제출용 소스입니다.
